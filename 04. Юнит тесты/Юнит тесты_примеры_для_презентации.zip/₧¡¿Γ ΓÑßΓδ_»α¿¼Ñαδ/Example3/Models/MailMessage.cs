﻿namespace Example3.Models
{
    public class MailMessage
    {
        public string To { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }
    }
}
