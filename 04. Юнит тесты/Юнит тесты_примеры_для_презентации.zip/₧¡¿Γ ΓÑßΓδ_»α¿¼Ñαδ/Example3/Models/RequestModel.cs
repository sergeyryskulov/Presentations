﻿using Example3.Constants.Enums;

namespace Example3.Models
{
    public class RequestModel
    {
        public string Title { get; set; }

        public string Description { get; set; }

        public RequestStatus Status { get; set; }

        public string InitiatorMail { get; set; }
    }
}
