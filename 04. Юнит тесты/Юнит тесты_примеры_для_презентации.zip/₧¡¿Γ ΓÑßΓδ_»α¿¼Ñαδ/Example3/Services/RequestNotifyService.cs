﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Example3.Constants.Enums;
using Example3.Models;
using Example3.Repositories;

namespace Example2.Services
{
    public class RequestNotifyService
    {
        private IMailSenderRepository _mailSenderRepository;

        public RequestNotifyService(IMailSenderRepository mailSenderRepository)
        {
            _mailSenderRepository = mailSenderRepository;
        }

        public void SendNotify(RequestModel request)
        {
            string messageBody = "";

            if (request.Status == RequestStatus.Created)
            {
                messageBody = $"Заявка создана. Название: {request.Title} Описание: {request.Description}";
            }
            else if (request.Status == RequestStatus.Canceled)
            {
                messageBody = $"Заявка отменена. Название: {request.Title} Описание: {request.Description}";
            }
            else if (request.Status == RequestStatus.Completed)
            {
                messageBody = $"Заявка выполнена. Название: {request.Title} Описание: {request.Description}";
            }

            _mailSenderRepository.SendMail(new MailMessage()
            {
                To = request.InitiatorMail,
                Subject = "Информация о заявке",
                Body = messageBody
            });
            
        }
    } 
}
