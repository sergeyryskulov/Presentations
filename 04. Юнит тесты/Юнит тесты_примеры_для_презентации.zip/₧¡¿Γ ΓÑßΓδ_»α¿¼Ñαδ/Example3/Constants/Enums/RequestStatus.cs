﻿namespace Example3.Constants.Enums
{
    public enum RequestStatus
    {
        Created,
        Completed,
        Canceled,
    }
}
