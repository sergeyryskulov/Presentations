﻿using Example3.Models;

namespace Example3.Repositories
{
    public interface IMailSenderRepository
    {
        void SendMail(MailMessage message);
    }
}