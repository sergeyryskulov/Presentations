﻿using Example3.Models;

namespace Example3.Repositories
{
    public class MailSenderRepository : IMailSenderRepository
    {

        public void SendMail(MailMessage message)
        {
            //отправка сообщения по почте
        }
    }
}
