﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    public class Calculator
    {
        public int Div(int a, int b)
        {
            return a / b;
        }
    }
}
