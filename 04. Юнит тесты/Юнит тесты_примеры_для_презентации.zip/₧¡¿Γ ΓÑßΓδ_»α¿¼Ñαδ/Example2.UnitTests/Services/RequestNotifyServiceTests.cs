﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Example2.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Example2.Constants.Enums;
using Example2.Models;
using Example2.Repositories;

namespace Example2.Services.Tests
{
    [TestClass()]
    public class RequestNotifyServiceTests
    {
       /* [TestMethod()]
        public void GenerateMessageTest()
        {
            var requestNotifyService = new RequestNotifyService(null); 
            
            var actualMessage = requestNotifyService.GenerateMessage(new RequestModel()
            {
                Status = RequestStatus.Created,
                Title = "title",
                Description = "description"
            });

            Assert.AreEqual("Заявка создана. Название: title Описание: description", actualMessage);
        }*/
    }
}