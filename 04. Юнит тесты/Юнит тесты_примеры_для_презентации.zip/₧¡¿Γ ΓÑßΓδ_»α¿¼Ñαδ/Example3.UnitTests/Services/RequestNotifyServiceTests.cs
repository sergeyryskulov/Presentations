﻿using System.IO;
using Example2.Services;
using Example3.Constants.Enums;
using Example3.Models;
using Example3.Repositories;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Example3.UnitTests.Services
{
    [TestClass()]
    public class RequestNotifyServiceTests
    {
        [TestMethod()]
        public void SendCreatedNotifyTest()
        {

            var mailSenderMock = new Mock<IMailSenderRepository>();

            RequestNotifyService requestNotifyService = new RequestNotifyService(mailSenderMock.Object);

            requestNotifyService.SendNotify(new RequestModel()
            {
                InitiatorMail = "initiatorMail",
                Status = RequestStatus.Created,
                Description = "description",
                Title = "title"
            });

            mailSenderMock.Verify(
                m=>m.SendMail(It.Is<MailMessage>(
                    t=>t.To == "initiatorMail" &&
                       t.Subject == "Информация о заявке" &&
                       t.Body == "Заявка создана. Название: title Описание: description")));


        }


        [TestMethod()]
        public void SendCompletedNotifyTest()
        {

            var mailSenderMock = new Mock<IMailSenderRepository>();

            RequestNotifyService requestNotifyService = new RequestNotifyService(mailSenderMock.Object);

            string expectedBody = File.ReadAllText("TestFiles/CompletedNotifyTest.txt");

            requestNotifyService.SendNotify(new RequestModel()
            {
                InitiatorMail = "initiatorMail",
                Status = RequestStatus.Completed,
                Description = "description",
                Title = "title"
            });

            mailSenderMock.Verify(
                m => m.SendMail(It.Is<MailMessage>(
                    t => t.To == "initiatorMail" &&
                         t.Subject == "Информация о заявке" &&
                         t.Body == expectedBody)));


        }


        [TestMethod()] 
        public void SendCancelledNotifyTest()
        {

            var mailSenderMock = new Mock<IMailSenderRepository>();

            RequestNotifyService requestNotifyService = new RequestNotifyService(mailSenderMock.Object);

            MailMessage savedMailMessage = null;

            mailSenderMock.Setup(m => m.SendMail(It.IsAny<MailMessage>()))
                .Callback<MailMessage>(t => savedMailMessage = t);

            requestNotifyService.SendNotify(new RequestModel()
            {
                InitiatorMail = "initiatorMail",
                Status = RequestStatus.Canceled,
                Description = "description",
                Title = "title"
            });

            Assert.AreEqual("initiatorMail", savedMailMessage.To);
            Assert.AreEqual("Информация о заявке", savedMailMessage.Subject);
            Assert.AreEqual("Заявка отменена. Название: title Описание: description", savedMailMessage.Body);

        }
    }
}