﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5.Repositories
{
    public class Repository4 : IRepository4
    {
        public string GetData4()
        {
            return "ok";
        }
    }
}
