﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5.Repositories
{
    public class Repository1 : IRepository1
    {
        public string GetData1()
        {
            return "ok";
        }
    }
}
