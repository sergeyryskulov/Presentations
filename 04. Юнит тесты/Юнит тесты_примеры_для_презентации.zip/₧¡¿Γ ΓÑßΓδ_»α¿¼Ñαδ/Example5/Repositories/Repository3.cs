﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5.Repositories
{
    public class Repository3 : IRepository3
    {
        public string GetData3()
        {
            return "ok";
        }
    }
}
