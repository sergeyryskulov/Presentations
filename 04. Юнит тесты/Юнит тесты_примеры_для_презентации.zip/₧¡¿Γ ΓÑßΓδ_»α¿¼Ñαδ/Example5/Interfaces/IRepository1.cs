﻿namespace Example5.Repositories
{
    public interface IRepository1
    {
        string GetData1();
    }
}