﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Example2.Constants.Enums;
using Example2.Models;
using Example2.Repositories;

namespace Example2.Services
{
    class RequestNotifyService
    {
        private MailSenderRepository _mailSenderRepository;

        public RequestNotifyService(MailSenderRepository mailSenderRepository)
        {
            _mailSenderRepository = mailSenderRepository;
        }

        public void SendNotify(RequestModel request)
        {
            string messageBody = "";

            if (request.Status == RequestStatus.Created)
            {
                messageBody = $"Заявка создана. Название: {request.Title} Описание: {request.Description}";
            }
            else if (request.Status == RequestStatus.Canceled)
            {
                messageBody = $"Заявка отменена. Название: {request.Title} Описание: {request.Description}";
            }
            else if (request.Status == RequestStatus.Completed)
            {
                messageBody = $"Заявка выполнена. Название: {request.Title} Описание: {request.Description}";
            }

            _mailSenderRepository.SendMail(new MailMessage()
            {
                To = request.InitiatorMail,
                Subject = "Информация о заявке",
                Body = messageBody
            });
            
        }
    }

    /*public class RequestNotifyService
    {
        private MailSenderRepository _mailSenderRepository;

        public RequestNotifyService(MailSenderRepository mailSenderRepository)
        {
            _mailSenderRepository = mailSenderRepository;
        }

        public string GenerateMessage(RequestModel request)
        {
            if (request.Status == RequestStatus.Created)
            {
                return $"Заявка создана. Название: {request.Title} Описание: {request.Description}";
            }
            if (request.Status == RequestStatus.Canceled)
            {
                return $"Заявка отменена. Название: {request.Title} Описание: {request.Description}";
            }
            if (request.Status == RequestStatus.Completed)
            {
                return  $"Заявка выполнена. Название: {request.Title} Описание: {request.Description}";
            }

            return "";
        }
        public void SendNotify(RequestModel request)
        {

            string messageBody = GenerateMessage(request);

            _mailSenderRepository.SendMail(new MailMessage()
            {
                To = request.InitiatorMail,
                Subject = "Информация о заявке",
                Body = messageBody
            });

        }
    }*/
}
