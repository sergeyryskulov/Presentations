﻿namespace Example3.Constants.Enums
{
    public enum OrderStatus
    {
        Created,
        Completed,
        Canceled,
    }
}
