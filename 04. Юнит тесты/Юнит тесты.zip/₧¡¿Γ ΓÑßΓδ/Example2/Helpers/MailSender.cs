﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Example2.Models;

namespace Example2.Repositories
{
    public class MailSender
    {

        public void SendMail(MailMessage message)
        {
            //отправка сообщения по почте
        }
    }
}
