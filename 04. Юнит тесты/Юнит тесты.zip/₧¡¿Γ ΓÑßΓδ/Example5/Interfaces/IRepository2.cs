﻿namespace Example5.Repositories
{
    public interface IRepository2
    {
        string GetData2();
    }
}