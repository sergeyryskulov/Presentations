﻿namespace Example5.Repositories
{
    public interface IRepository4
    {
        string GetData4();
    }
}