﻿namespace Example4.Context
{
    public interface IYandexContext
    {
        string SendRequest(string yandexApiUrl);
    }
}