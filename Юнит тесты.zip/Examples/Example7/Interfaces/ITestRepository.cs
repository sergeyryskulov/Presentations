﻿namespace Example6.Repository
{
    public interface ITestRepository
    {
        string Test();
    }
}