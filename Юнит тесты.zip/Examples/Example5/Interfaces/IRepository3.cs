﻿namespace Example5.Repositories
{
    public interface IRepository3
    {
        string GetData3();
    }
}