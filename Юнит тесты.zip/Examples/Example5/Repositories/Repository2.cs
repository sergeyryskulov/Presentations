﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5.Repositories
{
    public class Repository2 : IRepository2
    {
        public string GetData2()
        {
            return "ok";
        }
    }
}
