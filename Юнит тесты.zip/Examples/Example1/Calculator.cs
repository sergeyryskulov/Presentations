﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    public class Calculator
    {
        public int Div(int a, int b)
        {
            if (a == 3)
            {
                return 0;
            }
            return a / b;
        }

        public void Test1123()
        {
            ;
        }
    }
}
