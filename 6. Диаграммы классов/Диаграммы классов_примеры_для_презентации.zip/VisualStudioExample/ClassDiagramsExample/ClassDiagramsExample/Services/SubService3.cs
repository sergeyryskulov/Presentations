﻿using ClassDiagramsExample.Interface;
using ClassDiagramsExample.Repositories;
using ClassDiagramsExample.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample
{
    public class SubService3
    {
        IRepository3 _repository3;

        public SubService3(IRepository3 repository1)
        {
            _repository3 = repository1;            
        }

        public void Method3()
        {
          
        }
    }
}
