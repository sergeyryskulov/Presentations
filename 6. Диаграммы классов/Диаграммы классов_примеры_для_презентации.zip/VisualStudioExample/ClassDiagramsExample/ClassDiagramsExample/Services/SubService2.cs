﻿using ClassDiagramsExample.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample
{
    public class SubService2
    {
        public void Method123()
        {
            new Service4().Method();
        }

        public void OtherMethod(Service5 subService5)
        {
            subService5.Method();
        }
    }
}
