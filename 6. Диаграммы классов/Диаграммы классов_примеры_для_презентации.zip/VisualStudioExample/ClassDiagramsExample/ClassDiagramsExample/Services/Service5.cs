﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Services
{
    public class Service5
    {
        public void Method()
        {

        }

    }
}
