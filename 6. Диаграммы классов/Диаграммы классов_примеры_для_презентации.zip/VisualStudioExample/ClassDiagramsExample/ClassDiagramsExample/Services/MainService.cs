﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample
{
    public class MainService
    {
        SubService1 _subService1;

        SubService2 _subService2;

        SubService3 _subService3;

        public MainService(SubService1 subService1, SubService2 subService2, SubService3 subService3)
        {
            _subService1 = subService1;
            _subService2 = subService2;
            _subService3 = subService3;
        }

        public void MainMethod(string parameter)
        {
            _subService1.Method1();
            _subService2.Method123();
            _subService3.Method3();
         
        }
    }
}
