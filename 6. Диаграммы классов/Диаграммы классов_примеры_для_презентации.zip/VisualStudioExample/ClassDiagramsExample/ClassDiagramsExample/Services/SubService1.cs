﻿using ClassDiagramsExample.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample
{
    public class SubService1
    {
        Repository1 _repository1;
        Repository2 _repository2;

        public SubService1(Repository1 repository1, Repository2 repository2)
        {
            _repository1 = repository1;
            _repository2 = repository2;
        }

        public void Method1()
        {
           _repository1.GetData1();
        }
    }
}
