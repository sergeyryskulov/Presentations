﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Services
{
    public class Service4
    {

        public Service4()
        {
            
        }

        public void Method()
        {
            ;
        }
    }
}
