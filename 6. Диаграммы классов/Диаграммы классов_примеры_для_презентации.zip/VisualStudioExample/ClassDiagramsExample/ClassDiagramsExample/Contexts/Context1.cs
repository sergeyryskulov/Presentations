﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Contexts
{
    public class Context1
    {
        public void RunDatabaseQuery()
        {
            ;
        }
    }
}
