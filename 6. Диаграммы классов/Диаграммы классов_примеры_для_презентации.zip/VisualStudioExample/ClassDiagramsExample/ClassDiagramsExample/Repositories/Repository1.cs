﻿using ClassDiagramsExample.Contexts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Repositories
{
    public class Repository1
    {
        Context1 _context1;

        public Repository1(Context1 context1)
        {
            _context1 = context1;
        }

        public void GetData1()
        {
            _context1.RunDatabaseQuery();
        }
    }
}
