﻿using ClassDiagramsExample.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Repositories
{
    public class Repository3 : IRepository3
    {
        public string GetData()
        {
            return "data";
        }
    }

    public class Repo5 : Repository3
    {
        
    }
}
