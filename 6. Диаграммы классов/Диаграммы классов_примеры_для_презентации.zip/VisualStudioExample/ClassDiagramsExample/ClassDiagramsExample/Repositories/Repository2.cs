﻿using ClassDiagramsExample.Contexts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Repositories
{
    public class Repository2
    {
        Context1 _context1;

        public Repository2(Context1 context1)
        {
            _context1 = context1;
        }

        public void GetData2()
        {
            ;
        }
    }
}
