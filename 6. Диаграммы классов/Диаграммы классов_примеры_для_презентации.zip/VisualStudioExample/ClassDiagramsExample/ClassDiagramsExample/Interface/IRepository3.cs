﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagramsExample.Interface
{
    public interface IRepository3
    {
        public string GetData();
    }
}
